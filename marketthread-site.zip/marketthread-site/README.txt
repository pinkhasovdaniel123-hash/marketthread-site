MarketThread landing page

No build step is required. The site is a single static index.html file.

Recommended deployment:
1. Create a new Vercel project named marketthread.
2. Deploy index.html as the project root.
3. Add marketthreadai.com and www.marketthreadai.com as custom domains.
4. Follow Vercel's DNS instructions in Namecheap.
5. Do NOT remove or modify your existing Private Email MX/DKIM records.
